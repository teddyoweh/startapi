## Flask Boilerpate - updated!

Starter App, powered by Real Python

### Quick Start

Clone the repo, then:

```sh
$ git remote rm origin
$ git remote add origin <the location of my new git repository>
$ git push -u origin master
```

## Run

```sh
$ make server
```